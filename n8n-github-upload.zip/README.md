# n8n sur Render + Supabase

Ce dépôt contient tout ce qu'il faut pour déployer [n8n](https://n8n.io) gratuitement :

✅ Hébergement gratuit sur [Render](https://render.com)  
✅ Base PostgreSQL gratuite sur [Supabase](https://supabase.com)

## Étapes

1. Crée une base de données Supabase
2. Clone ou importe ce dépôt sur ton GitHub
3. Sur Render.com, crée un service "Web Service" Docker et connecte ce dépôt
4. Ajoute les variables d’environnement listées dans `.env.example`
